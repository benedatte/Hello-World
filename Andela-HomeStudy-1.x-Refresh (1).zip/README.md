# HomeStudy
Andela's home study curriculum

Go to http://curriculum.andela.co to view the home study curriculum
